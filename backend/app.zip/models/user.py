
from app import MODEL_TABLENAME, db
from .abstract_model import AbstractModel

class User(AbstractModel):
    __tablename__ = MODEL_TABLENAME.get('User')

    pk = db.Column(db.Integer, primary_key=True)
    email: str = db.Column(db.String(45))
    password: str = db.Column(db.String(45))
    messages = db.relationship('Message')

