1. Create .env file in `backend/` directory
2. Specify `DB_CONN_STR` variable there. For example `'postgresql+psycopg2://username:password@host/db_name'`
3. Run `python main.py` in `backend` directory